# Precompromise script for BFCSC Scrimmage  
  
# --Instructions--  
cd precompromise  
chmod 777 *  
./precomp  



# --To Do--  
Add webshells  

